@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Download it from https://nodejs.org then run this again. & pause & exit /b)
if not exist node_modules call npm install --no-package-lock
start "" http://localhost:8080
call npm run dev
pause
