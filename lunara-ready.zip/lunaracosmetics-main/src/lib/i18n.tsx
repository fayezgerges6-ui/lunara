import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Lang = "en" | "ar";

const dict = {
  en: {
    nav_shop: "Shop",
    nav_zoganon: "Zoganon",
    nav_about: "About",
    nav_account: "Account",
    hero_eyebrow: "Lunara Cosmetics",
    hero_title_1: "Beauty rituals,",
    hero_title_em: "gently",
    hero_title_2: " elevated.",
    hero_body: "Pure oils, botanical creams, and mindful skincare — crafted for the moments you take just for you.",
    hero_cta_shop: "Shop the Collections →",
    hero_cta_zog: "Discover Zoganon",
    cat_skincare: "Skincare",
    cat_makeup: "Makeup",
    cat_zoganon: "Zoganon",
    cat_bodybath: "Body & Bath",
    coming_soon: "Coming soon",
    shop_now: "Shop now",
    cat_full_line: "The full line, in stock.",
    cat_launching: "Launching soon.",
    zog_eyebrow: "Featured Line",
    zog_title_1: "Zoganon —",
    zog_title_2: "the full collection.",
    zog_body: "Pure oils, aromatherapy, creams, scrubs and salts — the entire Zoganon range, ready to order.",
    tab_all: "All",
    add: "Add +",
    loading_products: "Loading products…",
    about_eyebrow: "Our Story",
    about_title: "A ritual, not a routine.",
    about_p1: "Lunara was born from a belief that skincare is a quiet ceremony — a way to slow down, breathe, and return to yourself. Every oil, cream, and salt in our collection is chosen for how it feels as much as what it does.",
    about_p2: "We work with pure botanicals and small-batch formulations, sourced with care and finished by hand.",
    foot_care: "Care",
    foot_shipping: "Shipping",
    foot_returns: "Returns",
    foot_contact: "Contact",
    foot_stay: "Stay in touch",
    foot_orders_via: "Orders via WhatsApp:",
    foot_made: "Made with care in Egypt",
    foot_tagline: "Beauty rituals, gently elevated. Crafted with intention in Egypt.",
    bag: "Your Bag",
    empty_bag: "Your bag is empty.",
    subtotal: "Subtotal",
    checkout_wa: "Checkout via WhatsApp →",
    checkout_note: "Payment via InstaPay — we'll message you the details on WhatsApp.",
    remove: "Remove",
    checkout: "Checkout",
    total: "Total",
    pay_note: "Payment via InstaPay after confirmation",
    full_name: "Full name",
    phone_wa: "Phone (WhatsApp)",
    address: "Address",
    city_gov: "City / Governorate",
    notes_opt: "Notes (optional)",
    placing: "Placing order…",
    place_order: "Place order & open WhatsApp",
    place_note: "By placing the order you'll be redirected to WhatsApp with your order summary. We reply with the InstaPay details.",
    thanks: "Thank you 🌸",
    order_received_1: "Your order",
    order_received_2: "was received.",
    thanks_body: "A WhatsApp chat opened with your order summary. Send the message and we'll reply with the InstaPay details to complete payment.",
    // account panel
    account: "Account",
    signin: "Sign in",
    signup: "Create account",
    signout: "Sign out",
    my_orders: "My orders",
    email: "Email",
    password: "Password",
    guest_hint: "You can browse and check out as a guest — sign in to save an order history.",
    no_orders: "No orders yet.",
    back_store: "← Back to store",
    order: "Order",
    on_date: "on",
  },
  ar: {
    nav_shop: "المتجر",
    nav_zoganon: "زوجانون",
    nav_about: "من نحن",
    nav_account: "حسابي",
    hero_eyebrow: "لونارا كوزماتيكس",
    hero_title_1: "طقوس جمال",
    hero_title_em: "برقّة",
    hero_title_2: " مُتقنة.",
    hero_body: "زيوت نقية، كريمات نباتية، وعناية واعية بالبشرة — من أجل اللحظات اللي بتاخديها لنفسك.",
    hero_cta_shop: "تسوقي المجموعات ←",
    hero_cta_zog: "اكتشفي زوجانون",
    cat_skincare: "العناية بالبشرة",
    cat_makeup: "الميكب",
    cat_zoganon: "زوجانون",
    cat_bodybath: "الجسم والاستحمام",
    coming_soon: "قريباً",
    shop_now: "تسوّقي الآن",
    cat_full_line: "المجموعة كاملة ومتوفرة.",
    cat_launching: "قريباً جداً.",
    zog_eyebrow: "المجموعة المميزة",
    zog_title_1: "زوجانون —",
    zog_title_2: "المجموعة الكاملة.",
    zog_body: "زيوت نقية، أروماثيرابي، كريمات، سكراب وأملاح — كل مجموعة زوجانون جاهزة للطلب.",
    tab_all: "الكل",
    add: "إضافة +",
    loading_products: "جاري تحميل المنتجات…",
    about_eyebrow: "قصتنا",
    about_title: "طقس، مش روتين.",
    about_p1: "لونارا اتولدت من إيمان إن العناية بالبشرة احتفال هادي — طريقة تبطّئي بيها، تتنفسي، وترجعي لنفسك. كل زيت وكريم وملح في مجموعتنا مختار للإحساس اللي بيديهولك زي ما هو مختار للفايدة.",
    about_p2: "بنشتغل بنباتات نقية ودفعات صغيرة، مصادر مختارة بعناية وتشطيب باليد.",
    foot_care: "خدمة",
    foot_shipping: "الشحن",
    foot_returns: "الاسترجاع",
    foot_contact: "تواصل",
    foot_stay: "تواصلي معانا",
    foot_orders_via: "الطلبات على واتساب:",
    foot_made: "بحُب من مصر",
    foot_tagline: "طقوس جمال برقّة مُتقنة. مصنوعة بعناية في مصر.",
    bag: "شنطتك",
    empty_bag: "الشنطة فاضية.",
    subtotal: "الإجمالي الفرعي",
    checkout_wa: "إتمام الطلب عبر واتساب ←",
    checkout_note: "الدفع عن طريق إنستا باي — هنبعتلك التفاصيل على واتساب.",
    remove: "حذف",
    checkout: "إتمام الطلب",
    total: "الإجمالي",
    pay_note: "الدفع عن طريق إنستا باي بعد التأكيد",
    full_name: "الاسم بالكامل",
    phone_wa: "الموبايل (واتساب)",
    address: "العنوان",
    city_gov: "المدينة / المحافظة",
    notes_opt: "ملاحظات (اختياري)",
    placing: "جاري إرسال الطلب…",
    place_order: "أرسلي الطلب وافتحي واتساب",
    place_note: "لما تأكدي هيتفتحلك واتساب فيه ملخص الطلب. هنرد عليكي ببيانات الإنستا باي.",
    thanks: "شكراً 🌸",
    order_received_1: "طلبك رقم",
    order_received_2: "اتسجّل.",
    thanks_body: "اتفتحت شاشة واتساب فيها ملخص طلبك. ابعتي الرسالة وهنرد ببيانات الإنستا باي لإتمام الدفع.",
    account: "حسابي",
    signin: "تسجيل الدخول",
    signup: "إنشاء حساب",
    signout: "تسجيل الخروج",
    my_orders: "طلباتي",
    email: "الإيميل",
    password: "الباسورد",
    guest_hint: "تقدري تتصفحي وتطلبي كضيف — سجّلي دخولك لو عايزة تحفظي سجل الطلبات.",
    no_orders: "مفيش طلبات لسه.",
    back_store: "→ رجوع للمتجر",
    order: "طلب",
    on_date: "بتاريخ",
  },
} as const;

type Dict = typeof dict.en;
type Key = keyof Dict;

const LangCtx = createContext<{ lang: Lang; setLang: (l: Lang) => void; t: (k: Key) => string; dir: "ltr" | "rtl" }>({
  lang: "en",
  setLang: () => {},
  t: (k) => k,
  dir: "ltr",
});

export function LangProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>("en");

  useEffect(() => {
    const saved = (typeof window !== "undefined" && (localStorage.getItem("lunara_lang") as Lang | null)) || null;
    if (saved === "ar" || saved === "en") setLangState(saved);
  }, []);

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
      document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
    }
  }, [lang]);

  function setLang(l: Lang) {
    setLangState(l);
    if (typeof window !== "undefined") localStorage.setItem("lunara_lang", l);
  }

  const t = (k: Key) => dict[lang][k] ?? dict.en[k];
  return <LangCtx.Provider value={{ lang, setLang, t, dir: lang === "ar" ? "rtl" : "ltr" }}>{children}</LangCtx.Provider>;
}

export function useLang() {
  return useContext(LangCtx);
}
