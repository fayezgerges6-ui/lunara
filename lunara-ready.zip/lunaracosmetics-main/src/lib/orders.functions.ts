import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const ItemSchema = z.object({
  product_id: z.string().min(1).max(64),
  quantity: z.number().int().min(1).max(999),
});

const CreateOrderSchema = z.object({
  customer_name: z.string().trim().min(2).max(120),
  customer_phone: z.string().trim().min(6).max(30),
  customer_address: z.string().trim().min(4).max(500),
  city: z.string().trim().max(120).optional().nullable(),
  notes: z.string().trim().max(500).optional().nullable(),
  items: z.array(ItemSchema).min(1).max(50),
});

export const createOrder = createServerFn({ method: "POST" })
  .inputValidator((raw: unknown) => CreateOrderSchema.parse(raw))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    // Optionally attach the signed-in user (guest checkout is still allowed)
    let userId: string | null = null;
    const authHeader = getRequestHeader("authorization");
    if (authHeader?.toLowerCase().startsWith("bearer ")) {
      const token = authHeader.slice(7);
      try {
        const { data: u } = await supabaseAdmin.auth.getUser(token);
        userId = u.user?.id ?? null;
      } catch {
        userId = null;
      }
    }

    const ids = data.items.map((i) => i.product_id);
    const { data: products, error: pErr } = await supabaseAdmin
      .from("products")
      .select("id, name, price, active")
      .in("id", ids);
    if (pErr) throw new Error(pErr.message);

    const priceMap = new Map(products?.filter((p) => p.active).map((p) => [p.id, p]));
    let total = 0;
    const itemsToInsert = data.items.map((i) => {
      const p = priceMap.get(i.product_id);
      if (!p) throw new Error(`Product ${i.product_id} not available`);
      total += p.price * i.quantity;
      return {
        product_id: p.id,
        product_name: p.name,
        price: p.price,
        quantity: i.quantity,
      };
    });

    const { data: order, error: oErr } = await supabaseAdmin
      .from("orders")
      .insert({
        customer_name: data.customer_name,
        customer_phone: data.customer_phone,
        customer_address: data.customer_address,
        city: data.city ?? null,
        notes: data.notes ?? null,
        total,
        user_id: userId,
      })
      .select("id, order_number, total")
      .single();
    if (oErr || !order) throw new Error(oErr?.message ?? "Order failed");

    const { error: iErr } = await supabaseAdmin
      .from("order_items")
      .insert(itemsToInsert.map((it) => ({ ...it, order_id: order.id })));
    if (iErr) throw new Error(iErr.message);

    return {
      id: order.id,
      order_number: order.order_number,
      total: order.total,
    };
  });

export const listMyOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("orders")
      .select("id, order_number, status, total, created_at, estimated_delivery, admin_note, order_items(id, product_name, quantity, price)")
      .eq("user_id", context.userId)
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const listOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Forbidden");

    const { data, error } = await context.supabase
      .from("orders")
      .select("*, order_items(*)")
      .order("created_at", { ascending: false })
      .limit(500);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

const UpdateStatusSchema = z.object({
  id: z.string().uuid(),
  status: z.enum(["pending", "confirmed", "paid", "shipping", "delivered", "cancelled"]).optional(),
  estimated_delivery: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).nullable().optional(),
  admin_note: z.string().trim().max(500).nullable().optional(),
});

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((raw: unknown) => UpdateStatusSchema.parse(raw))
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Forbidden");

    const patch: {
      updated_at: string;
      status?: (typeof UpdateStatusSchema)["_type"]["status"];
      estimated_delivery?: string | null;
      admin_note?: string | null;
    } = { updated_at: new Date().toISOString() };
    if (data.status !== undefined) patch.status = data.status;
    if (data.estimated_delivery !== undefined) patch.estimated_delivery = data.estimated_delivery;
    if (data.admin_note !== undefined) patch.admin_note = data.admin_note;

    const { error } = await context.supabase
      .from("orders")
      .update(patch)
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const checkIsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    return { isAdmin: !!data };
  });
