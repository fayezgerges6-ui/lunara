import { Link, useNavigate } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQuery } from "@tanstack/react-query";
import { buildSuggestions, highlightParts, type Suggestion } from "@/lib/search-utils";
import { logSearchEvent } from "@/lib/analytics";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { createOrder } from "@/lib/orders.functions";
import { useLang } from "@/lib/i18n";
import lunaraMark from "@/assets/lunara-mark.png";
import productFallback from "@/assets/product-placeholder.jpg";

export function productImage(p: { image_url: string | null }) {
  return p.image_url && p.image_url.trim() ? p.image_url : productFallback;
}

export const WHATSAPP = "201022872608";

const iconProps = {
  width: 18,
  height: 18,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  "aria-hidden": true,
};

function UserIcon() {
  return (
    <svg {...iconProps}>
      <path d="M16 7a4 4 0 1 1-8 0 4 4 0 0 1 8 0ZM12 14a7 7 0 0 0-7 7h14a7 7 0 0 0-7-7Z" />
    </svg>
  );
}

function BagIcon() {
  return (
    <svg {...iconProps}>
      <path d="M16 11V7a4 4 0 0 0-8 0v4M5 9h14l1 12H4L5 9Z" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg {...iconProps} width={15} height={15}>
      <path d="M21 21l-5.2-5.2M17 10a7 7 0 1 1-14 0 7 7 0 0 1 14 0Z" />
    </svg>
  );
}


export function Highlight({ text, term }: { text: string; term: string }): ReactNode {
  return (
    <>
      {highlightParts(text, term).map((part, i) =>
        part.match ? <mark key={i}>{part.text}</mark> : <span key={i}>{part.text}</span>,
      )}
    </>
  );
}


export type Product = {
  id: string;
  name: string;
  name_ar: string | null;
  name_en: string | null;
  description_ar: string | null;
  description_en: string | null;
  category: string;
  brand: string | null;
  brand_ar: string | null;
  price: number;
  image_url: string | null;
};

export type CartItem = { id: string; name: string; price: number; qty: number };

export const CATEGORY_AR: Record<string, string> = {
  Oils: "زيوت",
  Shampoo: "شامبو",
  "Hair Care": "العناية بالشعر",
  "Creams & Lotions": "كريمات ولوشن",
  "Scrubs & Bath": "مقشرات واستحمام",
  Soap: "صابون",
  Fragrance: "عطور",
  Deodorants: "مزيلات العرق",
  Suncare: "العناية بالشمس",
  Makeup: "مكياج",
  "Oral Care": "العناية بالفم",
  "Personal Care": "العناية الشخصية",
  Accessories: "اكسسوارات",
  Toners: "تونر ومياه الزهور",
  Other: "منتجات أخرى",
};

export function brandLabel(p: { brand: string | null; brand_ar: string | null }, lang: string) {
  return (lang === "ar" ? p.brand_ar : p.brand) || p.brand || "";
}

export function brandSlug(brand: string) {
  return brand
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export function productName(p: Product, lang: string) {
  return (lang === "ar" ? p.name_ar : p.name_en) || p.name;
}

export function productDescription(p: Product, lang: string) {
  return (lang === "ar" ? p.description_ar : p.description_en) || "";
}

export function categoryLabel(category: string, lang: string) {
  return lang === "ar" ? (CATEGORY_AR[category] ?? category) : category;
}

export function categorySlug(category: string) {
  return category
    .toLowerCase()
    .replace(/&/g, "and")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

export async function fetchProducts(): Promise<Product[]> {
  const { data, error } = await supabase
    .from("products")
    .select("id, name, name_ar, name_en, description_ar, description_en, category, brand, brand_ar, price, image_url")
    .eq("active", true)
    .order("name");
  if (error) throw error;
  return data ?? [];
}


type ShopCtx = {
  cart: CartItem[];
  count: number;
  total: number;
  addToCart: (p: Product) => void;
  openCart: () => void;
};

const Ctx = createContext<ShopCtx | null>(null);

export function useShop() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useShop must be used inside ShopProvider");
  return v;
}

export function ShopProvider({ children }: { children: ReactNode }) {
  const { t } = useLang();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [confirmation, setConfirmation] = useState<{ order_number: number } | null>(null);

  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  const count = cart.reduce((s, i) => s + i.qty, 0);

  function addToCart(p: Product) {
    setCart((c) => {
      const ex = c.find((i) => i.id === p.id);
      if (ex) return c.map((i) => (i.id === p.id ? { ...i, qty: i.qty + 1 } : i));
      return [...c, { id: p.id, name: p.name, price: p.price, qty: 1 }];
    });
    setCartOpen(true);
  }
  function setQty(id: string, delta: number) {
    setCart((c) => c.map((i) => (i.id === id ? { ...i, qty: Math.max(0, i.qty + delta) } : i)).filter((i) => i.qty > 0));
  }
  function removeItem(id: string) {
    setCart((c) => c.filter((i) => i.id !== id));
  }

  const createOrderFn = useServerFn(createOrder);
  const orderMutation = useMutation({
    mutationFn: (input: {
      customer_name: string;
      customer_phone: string;
      customer_address: string;
      city?: string;
      notes?: string;
    }) =>
      createOrderFn({
        data: { ...input, items: cart.map((i) => ({ product_id: i.id, quantity: i.qty })) },
      }),
    onSuccess: (order, vars) => {
      const lines = cart.map((i) => `• ${i.name} × ${i.qty} = ${i.price * i.qty} EGP`).join("\n");
      const msg = `🌸 طلب جديد من Lunara\n\nرقم الطلب: #${order.order_number}\n\nالاسم: ${vars.customer_name}\nالتليفون: ${vars.customer_phone}\nالعنوان: ${vars.customer_address}${vars.city ? `\nالمدينة: ${vars.city}` : ""}${vars.notes ? `\nملاحظات: ${vars.notes}` : ""}\n\nالمنتجات:\n${lines}\n\nالإجمالي: ${order.total} جنيه\n\nمن فضلك ابعتيلي بيانات الإنستا باي 🙏`;
      window.open(`https://wa.me/${WHATSAPP}?text=${encodeURIComponent(msg)}`, "_blank");
      setConfirmation({ order_number: order.order_number });
      setCart([]);
      setCheckoutOpen(false);
      setCartOpen(false);
    },
  });

  return (
    <Ctx.Provider value={{ cart, count, total, addToCart, openCart: () => setCartOpen(true) }}>
      {children}

      <div className={`overlay ${cartOpen ? "open" : ""}`} onClick={() => setCartOpen(false)} />
      <aside className={`drawer ${cartOpen ? "open" : ""}`} aria-hidden={!cartOpen}>
        <div className="drawer-head">
          <h3>{t("bag")}</h3>
          <button className="x" onClick={() => setCartOpen(false)} aria-label="Close">×</button>
        </div>
        <div className="drawer-body">
          {cart.length === 0 ? (
            <p className="empty-cart">{t("empty_bag")}</p>
          ) : (
            cart.map((i) => (
              <div className="cart-item" key={i.id}>
                <div className="thumb"><img src={productFallback} alt="" loading="lazy" /></div>
                <div className="info">
                  <h4>{i.name}</h4>
                  <div className="sub">E£{i.price}</div>
                  <div className="qty">
                    <button onClick={() => setQty(i.id, -1)}>−</button>
                    <span>{i.qty}</span>
                    <button onClick={() => setQty(i.id, +1)}>+</button>
                    <button className="remove" onClick={() => removeItem(i.id)}>{t("remove")}</button>
                  </div>
                </div>
                <div style={{ fontFamily: "Instrument Serif, serif", fontSize: 17, fontWeight: 600 }}>
                  E£{i.price * i.qty}
                </div>
              </div>
            ))
          )}
        </div>
        <div className="drawer-foot">
          <div className="total-row"><span>{t("subtotal")}</span><strong>E£{total}</strong></div>
          <button
            className="btn"
            style={{ width: "100%", justifyContent: "center" }}
            disabled={cart.length === 0}
            onClick={() => setCheckoutOpen(true)}
          >
            {t("checkout_wa")}
          </button>
          <p className="checkout-note">{t("checkout_note")}</p>
        </div>
      </aside>

      {checkoutOpen && (
        <CheckoutModal
          total={total}
          submitting={orderMutation.isPending}
          error={orderMutation.error ? (orderMutation.error as Error).message : null}
          onClose={() => setCheckoutOpen(false)}
          onSubmit={(v) => orderMutation.mutate(v)}
        />
      )}

      {confirmation && (
        <div className="modal-overlay" onClick={() => setConfirmation(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()} style={{ textAlign: "center" }}>
            <button className="close" onClick={() => setConfirmation(null)}>×</button>
            <h2 style={{ fontSize: 26, marginBottom: 10 }}>{t("thanks")}</h2>
            <p style={{ opacity: 0.7, marginBottom: 14 }}>
              {t("order_received_1")} <strong>#{confirmation.order_number}</strong> {t("order_received_2")}
            </p>
            <p style={{ fontSize: 13.5, opacity: 0.7 }}>{t("thanks_body")}</p>
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}

export function SiteHeader() {
  const { t, lang, setLang } = useLang();
  const { count, openCart, addToCart } = useShop();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [openSug, setOpenSug] = useState(false);
  const [active, setActive] = useState(-1);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const { data: allProducts = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const suggestions = openSug ? buildSuggestions(allProducts, query, lang) : [];

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => { if (mounted) setUserEmail(data.user?.email ?? null); });
    const { data: sub } = supabase.auth.onAuthStateChange((_, session) => {
      setUserEmail(session?.user?.email ?? null);
    });
    return () => { mounted = false; sub.subscription.unsubscribe(); };
  }, []);

  function runSearch(q: string) {
    setOpenSug(false);
    setActive(-1);
    logSearchEvent({ event_type: "search", query: q, lang });
    navigate({ to: "/search", search: { q, cat: "", min: 0, max: 0, sort: "relevance" } });
  }

  function pick(s: Suggestion) {
    setOpenSug(false);
    setActive(-1);
    if (s.kind === "category") {
      logSearchEvent({ event_type: "suggestion_click", query, category: s.value, lang });
      setQuery("");
      navigate({ to: "/category/$slug", params: { slug: categorySlug(s.value) } });
    } else {
      logSearchEvent({ event_type: "suggestion_click", query, product_id: s.product.id, lang });
      setQuery(s.label);
      navigate({ to: "/product/$id", params: { id: s.product.id } });
    }
  }

  return (
    <header className="site">
      <div className="navrow">
        <Link to="/" className="brandmark" aria-label="Lunara home">
          <img className="logo" src={lunaraMark} alt="" />
          <div>
            <div className="word">LUNARA</div>
            <div className="sub">COSMETICS</div>
          </div>
        </Link>
        <nav>
          <ul>
            <li><Link to="/" hash="shop">{t("nav_shop")}</Link></li>
            <li><Link to="/" hash="zoganon">{t("nav_zoganon")}</Link></li>
            <li><Link to="/" hash="about">{t("nav_about")}</Link></li>
          </ul>
        </nav>
        <div className="navright">
          <div className="search-wrap">
            <form
              className="site-search"
              role="search"
              onSubmit={(e) => {
                e.preventDefault();
                if (active >= 0 && suggestions[active]) pick(suggestions[active]);
                else runSearch(query.trim());
              }}
            >
              <input
                type="search"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setOpenSug(true); setActive(-1); }}
                onFocus={() => setOpenSug(true)}
                onBlur={() => setTimeout(() => setOpenSug(false), 150)}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    setOpenSug(true);
                    setActive((i) => (suggestions.length ? (i + 1) % suggestions.length : -1));
                  } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    setActive((i) => (suggestions.length ? (i <= 0 ? suggestions.length - 1 : i - 1) : -1));
                  } else if (e.key === "Escape") {
                    setOpenSug(false);
                    setActive(-1);
                  }
                }}
                placeholder={lang === "ar" ? "ابحثي عن منتج…" : "Search products…"}
                aria-label={lang === "ar" ? "بحث" : "Search products"}
                role="combobox"
                aria-expanded={suggestions.length > 0}
                aria-controls="search-suggestions"
                aria-activedescendant={active >= 0 ? `sug-${active}` : undefined}
                autoComplete="off"
              />
              <button type="submit" aria-label={lang === "ar" ? "بحث" : "Search"}><SearchIcon /></button>
            </form>
            {suggestions.length > 0 && (
              <ul className="suggestions" id="search-suggestions" role="listbox">
                {suggestions.map((s, i) => (
                  <li key={`${s.kind}-${s.label}`}>
                    <button
                      type="button"
                      id={`sug-${i}`}
                      role="option"
                      aria-selected={i === active}
                      className={i === active ? "active" : ""}
                      onMouseEnter={() => setActive(i)}
                      onMouseDown={(e) => e.preventDefault()}
                      onClick={() => pick(s)}
                    >
                      <span className="sug-label"><Highlight text={s.label} term={query} /></span>
                      <span className="sug-meta">
                        {s.kind === "category"
                          ? (lang === "ar" ? "قسم" : "Category")
                          : `E£${s.product.price}`}
                      </span>
                    </button>
                    {s.kind === "product" && (
                      <button
                        type="button"
                        className="sug-add"
                        onMouseDown={(e) => e.preventDefault()}
                        onClick={() => { addToCart(s.product); setOpenSug(false); }}
                        aria-label={t("add")}
                      >
                        +
                      </button>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </div>


          <button
            className="cart-btn"
            onClick={() => setLang(lang === "en" ? "ar" : "en")}
            aria-label="Switch language"
            title="EN / AR"
            style={{ fontSize: 11, letterSpacing: "0.05em", fontWeight: 600 }}
          >
            {lang === "en" ? "AR" : "EN"}
          </button>
          {userEmail ? (
            <Link to="/orders" className="cart-btn" aria-label={t("nav_account")} title={userEmail}><UserIcon /></Link>
          ) : (
            <Link to="/auth" className="cart-btn" aria-label={t("signin")} title={t("signin")}><UserIcon /></Link>
          )}
          <button className="cart-btn" onClick={openCart} aria-label="Open cart">
            <BagIcon />
            {count > 0 && <span className="cart-count">{count}</span>}
          </button>

        </div>
      </div>
    </header>
  );
}


export function SiteFooter() {
  const { t } = useLang();
  return (
    <footer className="site">
      <div className="foot-top">
        <div>
          <div className="brandmark">
            <img className="logo" src={lunaraMark} alt="" />
            <div>
              <div className="word">LUNARA</div>
              <div className="sub">COSMETICS</div>
            </div>
          </div>
          <p>{t("foot_tagline")}</p>
        </div>
        <div>
          <h4>{t("nav_shop")}</h4>
          <ul><li>{t("cat_zoganon")}</li><li>{t("cat_skincare")}</li><li>{t("cat_bodybath")}</li></ul>
        </div>
        <div>
          <h4>{t("foot_care")}</h4>
          <ul><li>{t("foot_shipping")}</li><li>{t("foot_returns")}</li><li>{t("foot_contact")}</li></ul>
        </div>
        <div>
          <h4>{t("foot_stay")}</h4>
          <p>{t("foot_orders_via")} +{WHATSAPP}</p>
        </div>
      </div>
      <div className="foot-bottom">
        <span>© {new Date().getFullYear()} Lunara Cosmetics</span>
        <span>{t("foot_made")}</span>
      </div>
    </footer>
  );
}

export function ProductCard({ p, term }: { p: Product; term?: string }) {
  const { t, lang } = useLang();
  const { addToCart } = useShop();
  const name = productName(p, lang);
  return (
    <article className="card">
      <Link
        to="/product/$id"
        params={{ id: p.id }}
        style={{ color: "inherit", textDecoration: "none" }}
        onClick={() => term && logSearchEvent({ event_type: "result_click", query: term, product_id: p.id, lang })}
      >
        <div className="card-image">
          <img src={productImage(p)} alt={name} loading="lazy" width={816} height={816} />
        </div>
        {p.brand && <div className="card-brand">{brandLabel(p, lang)}</div>}
        <h3>{term ? <Highlight text={name} term={term} /> : name}</h3>
      </Link>
      <div className="row">
        <span className="price">E£{p.price}</span>
        <button className="add-btn" onClick={() => addToCart(p)}>{t("add")}</button>
      </div>
    </article>
  );
}


function CheckoutModal(props: {
  total: number;
  submitting: boolean;
  error: string | null;
  onClose: () => void;
  onSubmit: (v: { customer_name: string; customer_phone: string; customer_address: string; city?: string; notes?: string }) => void;
}) {
  const { t } = useLang();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [notes, setNotes] = useState("");

  return (
    <div className="modal-overlay" onClick={props.onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <button className="close" onClick={props.onClose}>×</button>
        <h2 style={{ fontSize: 24, marginBottom: 6 }}>{t("checkout")}</h2>
        <p className="sub" style={{ opacity: 0.6, fontSize: 13, marginBottom: 18 }}>
          {t("total")}: <strong>E£{props.total}</strong> · {t("pay_note")}
        </p>
        <form
          className="co-form"
          onSubmit={(e) => {
            e.preventDefault();
            props.onSubmit({
              customer_name: name.trim(),
              customer_phone: phone.trim(),
              customer_address: address.trim(),
              city: city.trim() || undefined,
              notes: notes.trim() || undefined,
            });
          }}
        >
          <div>
            <label htmlFor="n">{t("full_name")}</label>
            <input id="n" required minLength={2} maxLength={120} value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label htmlFor="p">{t("phone_wa")}</label>
            <input id="p" required minLength={6} maxLength={30} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="01xxxxxxxxx" />
          </div>
          <div>
            <label htmlFor="a">{t("address")}</label>
            <textarea id="a" required minLength={4} maxLength={500} value={address} onChange={(e) => setAddress(e.target.value)} />
          </div>
          <div>
            <label htmlFor="c">{t("city_gov")}</label>
            <input id="c" maxLength={120} value={city} onChange={(e) => setCity(e.target.value)} />
          </div>
          <div>
            <label htmlFor="no">{t("notes_opt")}</label>
            <textarea id="no" maxLength={500} value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          {props.error && <p className="error-msg">{props.error}</p>}
          <button type="submit" className="btn" style={{ width: "100%", justifyContent: "center", marginTop: 8 }} disabled={props.submitting}>
            {props.submitting ? t("placing") : t("place_order")}
          </button>
          <p className="checkout-note">{t("place_note")}</p>
        </form>
      </div>
    </div>
  );
}
