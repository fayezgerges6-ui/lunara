import type { Product } from "@/lib/shop";
import { CATEGORY_AR } from "@/lib/shop";

export function normalize(s: string) {
  return s
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/\s+/g, " ")
    .trim();
}

function searchableNames(p: Product) {
  return [p.name, p.name_en, p.name_ar].filter(Boolean).map((n) => normalize(n as string));
}

function searchableCategories(p: Product) {
  return [p.category, CATEGORY_AR[p.category]].filter(Boolean).map((c) => normalize(c as string));
}

/** Higher = more relevant. 0 means no match. */
export function scoreProduct(p: Product, term: string) {
  const q = normalize(term);
  if (!q) return 0;
  const names = searchableNames(p);
  const cats = searchableCategories(p);
  const words = q.split(" ").filter(Boolean);

  let score = 0;
  if (names.some((n) => n === q)) score += 200;
  else if (names.some((n) => n.startsWith(q))) score += 120;
  else if (names.some((n) => n.includes(q))) score += 80;

  if (cats.some((c) => c === q)) score += 60;
  else if (cats.some((c) => c.includes(q))) score += 30;

  let matchedWords = 0;
  for (const w of words) {
    if (names.some((n) => n.includes(w))) {
      matchedWords++;
      score += names.some((n) => n.startsWith(w)) ? 25 : 15;
    } else if (cats.some((c) => c.includes(w))) {
      matchedWords++;
      score += 8;
    }
  }
  if (words.length > 1 && matchedWords === words.length) score += 20;
  if (score === 0) return 0;

  // shorter names that match are usually the better hit
  score += Math.max(0, 20 - Math.min(...names.map((n) => n.length)) / 4);
  return score;
}

export function searchProducts(products: Product[], term: string) {
  return products
    .map((p) => ({ p, s: scoreProduct(p, term) }))
    .filter((r) => r.s > 0)
    .sort((a, b) => b.s - a.s || a.p.name.localeCompare(b.p.name))
    .map((r) => r.p);
}

export type Suggestion =
  | { kind: "product"; label: string; product: Product }
  | { kind: "category"; label: string; value: string };

export function buildSuggestions(
  products: Product[],
  term: string,
  lang: string,
  limit = 7,
): Suggestion[] {
  const q = normalize(term);
  if (!q) return [];
  const label = (p: Product) => ((lang === "ar" ? p.name_ar : p.name_en) || p.name);

  const cats = Array.from(new Set(products.map((p) => p.category)))
    .filter((c) => normalize(c).includes(q) || normalize(CATEGORY_AR[c] ?? "").includes(q))
    .slice(0, 3)
    .map(
      (c) =>
        ({
          kind: "category",
          label: lang === "ar" ? (CATEGORY_AR[c] ?? c) : c,
          value: c,
        }) as Suggestion,
    );

  const prods = searchProducts(products, term)
    .slice(0, Math.max(0, limit - cats.length))
    .map((p) => ({ kind: "product", label: label(p), product: p }) as Suggestion);

  return [...cats, ...prods];
}

/** Split `text` into parts, flagging the ones that match `term` for highlighting. */
export function highlightParts(text: string, term: string): { text: string; match: boolean }[] {
  const words = Array.from(new Set(normalize(term).split(" ").filter((w) => w.length > 1)));
  if (words.length === 0) return [{ text, match: false }];
  const norm = normalize(text);
  const flags = new Array(text.length).fill(false);
  // normalize() keeps a 1:1 char mapping for the substitutions used above,
  // except for whitespace collapsing — guard against a length mismatch.
  if (norm.length !== text.length) return [{ text, match: false }];
  for (const w of words) {
    let i = norm.indexOf(w);
    while (i !== -1) {
      for (let k = i; k < i + w.length; k++) flags[k] = true;
      i = norm.indexOf(w, i + w.length);
    }
  }
  const parts: { text: string; match: boolean }[] = [];
  let buf = text[0];
  for (let i = 1; i < text.length; i++) {
    if (flags[i] === flags[i - 1]) buf += text[i];
    else {
      parts.push({ text: buf, match: flags[i - 1] });
      buf = text[i];
    }
  }
  parts.push({ text: buf, match: flags[text.length - 1] });
  return parts;
}
