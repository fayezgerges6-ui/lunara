import { supabase } from "@/integrations/supabase/client";

export type SearchEvent = {
  event_type: "search" | "result_click" | "suggestion_click" | "filter";
  query?: string | null;
  product_id?: string | null;
  category?: string | null;
  min_price?: number | null;
  max_price?: number | null;
  sort?: string | null;
  results_count?: number | null;
  lang?: string | null;
};

export function logSearchEvent(e: SearchEvent) {
  if (typeof window === "undefined") return;
  void supabase
    .from("search_events")
    .insert({
      event_type: e.event_type,
      query: e.query?.slice(0, 200) ?? null,
      product_id: e.product_id ?? null,
      category: e.category ?? null,
      min_price: e.min_price ?? null,
      max_price: e.max_price ?? null,
      sort: e.sort ?? null,
      results_count: e.results_count ?? null,
      lang: e.lang ?? null,
    })
    .then(() => undefined, () => undefined);
}
