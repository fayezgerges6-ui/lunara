import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ShopProvider,
  SiteHeader,
  SiteFooter,
  ProductCard,
  brandLabel,
  brandSlug,
  categoryLabel,
  categorySlug,
  fetchProducts,
  productDescription,
  productImage,
  productName,
  useShop,
  WHATSAPP,
  type Product,
} from "@/lib/shop";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/product/$id")({
  head: ({ params }) => {
    const title = `Product ${params.id} — Lunara Cosmetics`;
    const description = "Natural cosmetics from Lunara: pure oils, botanical creams and bath rituals, delivered across Egypt with WhatsApp checkout.";
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "product" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const { data: products = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const product = products.find((p) => p.id === id);

  return (
    <ShopProvider>
      <SiteHeader />
      {product ? (
        <ProductDetail p={product} related={products.filter((x) => x.category === product.category && x.id !== product.id).slice(0, 4)} />
      ) : (
        <section className="zoganon" style={{ paddingTop: 60, minHeight: "50vh" }}>
          <div className="wrap" style={{ textAlign: "center", opacity: 0.7 }}>
            {isLoading ? "…" : <Link to="/" className="btn">Go home</Link>}
          </div>
        </section>
      )}
      <SiteFooter />
    </ShopProvider>
  );
}

function ProductDetail({ p, related }: { p: Product; related: Product[] }) {
  const { lang, t } = useLang();
  const { addToCart } = useShop();
  const ar = lang === "ar";
  const name = productName(p, lang);

  const guarantees = ar
    ? ["منتج أصلي 100% من Lunara", "شحن لكل محافظات مصر", "الدفع عند الاستلام أو إنستا باي", "استبدال خلال 14 يوم لو المنتج مقفول"]
    : ["100% authentic Lunara product", "Delivery to all Egyptian governorates", "Cash on delivery or InstaPay", "14-day exchange on unopened items"];

  const waText = encodeURIComponent(
    ar ? `مرحباً، عايزة أسأل عن: ${name} (${p.price} جنيه)` : `Hi, I'd like to ask about: ${name} (${p.price} EGP)`,
  );

  return (
    <>
      <section className="zoganon" style={{ paddingTop: 36 }}>
        <div className="wrap">
          <p className="eyebrow" style={{ marginBottom: 18 }}>
            <Link to="/" hash="zoganon">{t("nav_shop")}</Link>
            {p.brand && (
              <>
                {" · "}
                <Link to="/brand/$slug" params={{ slug: brandSlug(p.brand) }}>{brandLabel(p, lang)}</Link>
              </>
            )}
            {" · "}
            <Link to="/category/$slug" params={{ slug: categorySlug(p.category) }}>{categoryLabel(p.category, lang)}</Link>
          </p>

          <div className="pdp">
            <div className="pdp-image">
              <img src={productImage(p)} alt={name} width={816} height={816} />
            </div>
            <div className="pdp-info">
              {p.brand && <p className="pdp-brand">{brandLabel(p, lang)}</p>}
              <h1>{name}</h1>
              <div className="pdp-price">E£{p.price}</div>

              <div className="pdp-actions">
                <button className="btn" onClick={() => addToCart(p)}>{t("add")}</button>
                <a className="btn ghost" href={`https://wa.me/${WHATSAPP}?text=${waText}`} target="_blank" rel="noreferrer">
                  {ar ? "اسألي على واتساب" : "Ask on WhatsApp"}
                </a>
              </div>

              <ul className="pdp-guarantees">
                {guarantees.map((g) => <li key={g}>{g}</li>)}
              </ul>

              {productDescription(p, lang) && <p className="pdp-desc">{productDescription(p, lang)}</p>}

              <div className="pdp-contact">
                <h3>{ar ? "تواصلي معانا" : "Contact us"}</h3>
                <p>
                  {ar ? "واتساب: " : "WhatsApp: "}
                  <a href={`https://wa.me/${WHATSAPP}`} target="_blank" rel="noreferrer">+{WHATSAPP}</a>
                </p>
                <p>{ar ? "الطلبات والدفع بيتم عن طريق واتساب وإنستا باي." : "Orders and payment are handled over WhatsApp and InstaPay."}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="pdp-bar">
        <div className="pdp-bar-price">
          <span>{name}</span>
          <strong>E£{p.price}</strong>
        </div>
        <button className="btn" onClick={() => addToCart(p)}>{t("add")}</button>
        <a className="btn ghost" href={`https://wa.me/${WHATSAPP}?text=${waText}`} target="_blank" rel="noreferrer" aria-label="WhatsApp">
          WhatsApp
        </a>
      </div>

      {related.length > 0 && (
        <section className="zoganon">
          <div className="wrap">
            <div className="zog-head">
              <div><h2 style={{ fontSize: 26 }}>{ar ? "منتجات مشابهة" : "You may also like"}</h2></div>
            </div>
            <div className="grid">
              {related.map((r) => <ProductCard key={r.id} p={r} />)}
            </div>
          </div>
        </section>
      )}
    </>
  );
}
