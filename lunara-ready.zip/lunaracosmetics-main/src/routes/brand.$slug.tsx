import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import {
  ShopProvider,
  SiteHeader,
  SiteFooter,
  ProductCard,
  brandLabel,
  brandSlug,
  categoryLabel,
  categorySlug,
  fetchProducts,
} from "@/lib/shop";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/brand/$slug")({
  head: ({ params }) => {
    const label = params.slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    const title = `${label} — Lunara Cosmetics`;
    const description = `Shop all ${label} products at Lunara Cosmetics: oils, hair care, skincare and more. Delivery across Egypt with WhatsApp checkout.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: BrandPage,
  notFoundComponent: () => (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: "center" }}>
        <h1 style={{ fontSize: 22 }}>Brand not found</h1>
        <Link to="/" className="btn" style={{ marginTop: 12 }}>Go home</Link>
      </div>
    </div>
  ),
});

function BrandPage() {
  const { slug } = Route.useParams();
  const { t, lang } = useLang();
  const [cat, setCat] = useState("");
  const { data: products = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });

  const items = useMemo(
    () => products.filter((p) => p.brand && brandSlug(p.brand) === slug),
    [products, slug],
  );
  const brands = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of products) if (p.brand) m.set(p.brand, (m.get(p.brand) ?? 0) + 1);
    return Array.from(m.entries()).sort((a, b) => b[1] - a[1]);
  }, [products]);

  const cats = Array.from(new Set(items.map((p) => p.category))).sort();
  const shown = cat ? items.filter((p) => p.category === cat) : items;
  const label = items[0] ? brandLabel(items[0], lang) : slug.replace(/-/g, " ");

  return (
    <ShopProvider>
      <SiteHeader />
      <section className="zoganon" style={{ paddingTop: 40 }}>
        <div className="wrap">
          <div className="zog-head">
            <div>
              <p className="eyebrow">
                <Link to="/" hash="brands">{lang === "ar" ? "البراندات" : "Brands"}</Link> · {items.length} {t("tab_all")}
              </p>
              <h2 style={{ textTransform: "capitalize" }}>{label}</h2>
            </div>
          </div>

          <div className="tabs">
            <button className={`tab ${cat === "" ? "active" : ""}`} onClick={() => setCat("")}>{t("tab_all")}</button>
            {cats.map((c) => (
              <button key={c} className={`tab ${cat === c ? "active" : ""}`} onClick={() => setCat(c)}>
                {categoryLabel(c, lang)}
              </button>
            ))}
          </div>

          <div className="grid">
            {shown.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
          {shown.length === 0 && (
            <p style={{ opacity: 0.6, textAlign: "center", padding: "40px 0" }}>
              {isLoading ? t("loading_products") : "—"}
            </p>
          )}

          <div className="tabs" style={{ marginTop: 34 }}>
            {brands.map(([b, n]) => (
              <Link
                key={b}
                to="/brand/$slug"
                params={{ slug: brandSlug(b) }}
                className={`tab ${brandSlug(b) === slug ? "active" : ""}`}
              >
                {b} ({n})
              </Link>
            ))}
          </div>

          <div className="tabs" style={{ marginTop: 14 }}>
            {Array.from(new Set(products.map((p) => p.category))).sort().map((c) => (
              <Link key={c} to="/category/$slug" params={{ slug: categorySlug(c) }} className="tab">
                {categoryLabel(c, lang)}
              </Link>
            ))}
          </div>
        </div>
      </section>
      <SiteFooter />
    </ShopProvider>
  );
}
