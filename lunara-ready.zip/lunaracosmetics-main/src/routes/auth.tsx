import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useLang } from "@/lib/i18n";

const searchSchema = z.object({
  redirect: z.string().optional(),
});

export const Route = createFileRoute("/auth")({
  validateSearch: (raw) => searchSchema.parse(raw),
  head: () => ({
    meta: [
      { title: "Sign in — Lunara" },
      { name: "description", content: "Sign in to Lunara to save your order history." },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { redirect } = Route.useSearch();
  const { t, lang } = useLang();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function afterSignIn() {
    // Check role → admins go to /admin, others go to /orders (or provided redirect)
    const { data: user } = await supabase.auth.getUser();
    if (!user.user) return;
    const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", user.user.id);
    const isAdmin = (roles ?? []).some((r) => r.role === "admin");
    const dest = redirect || (isAdmin ? "/admin" : "/orders");
    navigate({ to: dest });
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setInfo(null);
    setLoading(true);
    try {
      if (mode === "signup") {
        const { error } = await supabase.auth.signUp({
          email,
          password,
          options: { emailRedirectTo: window.location.origin + "/orders" },
        });
        if (error) throw error;
        // Try immediate sign-in (works when email confirmation is disabled)
        const { error: sErr } = await supabase.auth.signInWithPassword({ email, password });
        if (sErr) {
          setInfo(lang === "ar" ? "الحساب اتعمل. لو الإيميل محتاج تأكيد، شوفي البريد بتاعك." : "Account created. Check your inbox if email confirmation is required.");
          setMode("signin");
        } else {
          await afterSignIn();
        }
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        await afterSignIn();
      }
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Lunara</h1>
        <p className="sub">
          {lang === "ar"
            ? "سجّلي دخولك عشان تتابعي طلباتك."
            : "Sign in to view your order history."}
        </p>
        <div className="auth-tabs">
          <button className={mode === "signin" ? "active" : ""} onClick={() => setMode("signin")} type="button">{t("signin")}</button>
          <button className={mode === "signup" ? "active" : ""} onClick={() => setMode("signup")} type="button">{t("signup")}</button>
        </div>
        <form onSubmit={submit} className="co-form">
          <div>
            <label htmlFor="email">{t("email")}</label>
            <input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <label htmlFor="pw">{t("password")}</label>
            <input id="pw" type="password" required minLength={6} value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          {error && <p className="error-msg">{error}</p>}
          {info && <p className="success-msg">{info}</p>}
          <button className="btn" style={{ width: "100%", justifyContent: "center" }} disabled={loading}>
            {loading ? "…" : mode === "signin" ? t("signin") : t("signup")}
          </button>
        </form>
        <p style={{ fontSize: 12, marginTop: 16, textAlign: "center", opacity: 0.6 }}>
          <Link to="/">{t("back_store")}</Link>
        </p>
      </div>
    </div>
  );
}
