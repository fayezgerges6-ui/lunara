import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useMemo } from "react";
import {
  ShopProvider,
  SiteHeader,
  SiteFooter,
  ProductCard,
  brandSlug,
  categoryLabel,
  categorySlug,
  fetchProducts,
} from "@/lib/shop";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Lunara Cosmetics — Beauty rituals, gently elevated" },
      { name: "description", content: "Pure oils, botanical creams, shampoo and skincare from Zoganon, Isis, Vatika, Horus and more. Shop by brand or category with WhatsApp checkout in Egypt." },
      { property: "og:title", content: "Lunara Cosmetics" },
      { property: "og:description", content: "Beauty rituals, gently elevated. Shop oils, hair care and skincare by brand or category." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const { data: products = [] } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });
  const { t, lang } = useLang();

  const categories = useMemo(() => {
    const map = new Map<string, number>();
    for (const p of products) map.set(p.category, (map.get(p.category) ?? 0) + 1);
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [products]);

  const brands = useMemo(() => {
    const map = new Map<string, { ar: string | null; n: number }>();
    for (const p of products) {
      if (!p.brand) continue;
      const e = map.get(p.brand) ?? { ar: p.brand_ar, n: 0 };
      e.n += 1;
      map.set(p.brand, e);
    }
    return Array.from(map.entries()).sort((a, b) => b[1].n - a[1].n);
  }, [products]);


  return (
    <ShopProvider>
      <SiteHeader />

      <section className="hero">
        <div className="hero-bg" aria-hidden="true"><span>Lunara</span></div>
        <div className="hero-veil" aria-hidden="true" />
        <div className="hero-inner">
          <div className="hero-copy">
            <p className="eyebrow">{t("hero_eyebrow")}</p>
            <h1>{t("hero_title_1")}<br /><em>{t("hero_title_em")}</em>{t("hero_title_2")}</h1>
            <p>{t("hero_body")}</p>
            <div className="hero-actions">
              <a href="#shop" className="btn">{t("hero_cta_shop")}</a>
              <a href="#brands" className="btn ghost">{t("hero_cta_zog")}</a>
            </div>
          </div>
        </div>
      </section>

      <section className="categories" id="shop">
        <div className="wrap">
          <div className="sec-head">
            <div>
              <p className="eyebrow">{lang === "ar" ? "الأقسام" : "Categories"}</p>
              <h2>{lang === "ar" ? "الأساسيات" : "The Essentials"}</h2>
              <div className="rule" />
            </div>
          </div>

          <div className="feature-grid">
            {categories[0] && (
              <Link
                to="/category/$slug"
                params={{ slug: categorySlug(categories[0][0]) }}
                className="feat lg"
              >
                <span className="num">01</span>
                <h3>{categoryLabel(categories[0][0], lang)}</h3>
                <span className="meta">{categories[0][1]} {t("tab_all")}</span>
                <span className="go">{t("shop_now")}</span>
              </Link>
            )}
            <div className="feature-side">
              {categories[1] && (
                <Link to="/category/$slug" params={{ slug: categorySlug(categories[1][0]) }} className="feat dark">
                  <span className="num">02</span>
                  <h3>{categoryLabel(categories[1][0], lang)}</h3>
                  <span className="meta">{categories[1][1]} {t("tab_all")}</span>
                  <span className="go">{t("shop_now")}</span>
                </Link>
              )}
              {categories[2] && (
                <Link to="/category/$slug" params={{ slug: categorySlug(categories[2][0]) }} className="feat light">
                  <span className="blob" aria-hidden="true" />
                  <span className="num">03</span>
                  <h3>{categoryLabel(categories[2][0], lang)}</h3>
                  <span className="meta">{categories[2][1]} {t("tab_all")}</span>
                  <span className="go">{t("shop_now")}</span>
                </Link>
              )}
            </div>
          </div>

          <div className="cat-grid">
            {categories.slice(3).map(([c, n]) => (
              <Link key={c} to="/category/$slug" params={{ slug: categorySlug(c) }} className="cat-card">
                <div className="icon">{c.charAt(0)}</div>
                <div>
                  <h3>{categoryLabel(c, lang)}</h3>
                  <p>{n} {t("tab_all")}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>


      <section className="zoganon" id="brands">
        <div className="wrap">
          <div className="zog-head">
            <div>
              <p className="eyebrow">{lang === "ar" ? "براندات" : "Brands"}</p>
              <h2>{lang === "ar" ? "اتسوقي حسب البراند" : "Shop by brand"}</h2>
            </div>
            <p>
              {lang === "ar"
                ? "كل براند وتحته منتجاته، وكل تصنيف زي الزيوت بيجمع منتجات كل البراندات."
                : "Browse each brand's own line, or pick a category like Oils to see it across every brand."}
            </p>
          </div>
          <div className="brand-grid">
            {brands.map(([b, info]) => (
              <Link key={b} to="/brand/$slug" params={{ slug: brandSlug(b) }} className="brand-card">
                <span className="brand-name">{lang === "ar" ? (info.ar ?? b) : b}</span>
                <span className="brand-count">{info.n}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="zoganon" id="zoganon">
        <div className="wrap">
          <div className="zog-head">
            <div>
              <p className="eyebrow">{t("zog_eyebrow")}</p>
              <h2>{t("zog_title_1")}<br />{t("zog_title_2")}</h2>
            </div>
            <p>{t("zog_body")}</p>
          </div>
          <div className="tabs">
            <span className="tab active">{t("tab_all")}</span>
            {categories.map(([c]) => (
              <Link key={c} to="/category/$slug" params={{ slug: categorySlug(c) }} className="tab">
                {categoryLabel(c, lang)}
              </Link>
            ))}
          </div>
          <div className="grid">
            {products.slice(0, 24).map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
          {products.length === 0 && (
            <p style={{ opacity: 0.6, textAlign: "center", padding: "40px 0" }}>{t("loading_products")}</p>
          )}
        </div>
      </section>


      <section className="about" id="about">
        <div className="wrap">
          <div className="about-badge"><div className="orb">L</div></div>
          <div>
            <p className="eyebrow">{t("about_eyebrow")}</p>
            <h2>{t("about_title")}</h2>
            <p>{t("about_p1")}</p>
            <p>{t("about_p2")}</p>
          </div>
        </div>
      </section>

      <SiteFooter />
    </ShopProvider>
  );
}
