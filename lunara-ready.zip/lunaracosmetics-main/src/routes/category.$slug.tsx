import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ShopProvider,
  SiteHeader,
  SiteFooter,
  ProductCard,
  categoryLabel,
  categorySlug,
  fetchProducts,
} from "@/lib/shop";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/category/$slug")({
  head: ({ params }) => {
    const label = params.slug.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
    const title = `${label} — Lunara Cosmetics`;
    const description = `Shop ${label} from the Zoganon collection at Lunara Cosmetics. Delivery across Egypt, checkout via WhatsApp.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
        { property: "og:type", content: "website" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: CategoryPage,
  notFoundComponent: () => (
    <div className="auth-page">
      <div className="auth-card" style={{ textAlign: "center" }}>
        <h1 style={{ fontSize: 22 }}>Category not found</h1>
        <Link to="/" className="btn" style={{ marginTop: 12 }}>Go home</Link>
      </div>
    </div>
  ),
});

function CategoryPage() {
  const { slug } = Route.useParams();
  const { t, lang } = useLang();
  const { data: products = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });

  const items = products.filter((p) => categorySlug(p.category) === slug);
  const label = items[0]?.category ?? slug.replace(/-/g, " ");
  const all = Array.from(new Set(products.map((p) => p.category))).sort();

  return (
    <ShopProvider>
      <SiteHeader />
      <section className="zoganon" style={{ paddingTop: 40 }}>
        <div className="wrap">
          <div className="zog-head">
            <div>
              <p className="eyebrow">
                <Link to="/" hash="zoganon">{t("nav_shop")}</Link> · {items.length} {t("tab_all")}
              </p>
              <h2 style={{ textTransform: "capitalize" }}>{categoryLabel(label, lang)}</h2>
            </div>
          </div>
          <div className="tabs">
            <Link to="/" hash="zoganon" className="tab">{t("tab_all")}</Link>
            {all.map((c) => (
              <Link
                key={categoryLabel(c, lang)}
                to="/category/$slug"
                params={{ slug: categorySlug(c) }}
                className={`tab ${categorySlug(c) === slug ? "active" : ""}`}
              >
                {categoryLabel(c, lang)}
              </Link>
            ))}
          </div>
          <div className="grid">
            {items.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
          {items.length === 0 && (
            <p style={{ opacity: 0.6, textAlign: "center", padding: "40px 0" }}>
              {isLoading ? t("loading_products") : "—"}
            </p>
          )}
        </div>
      </section>
      <SiteFooter />
    </ShopProvider>
  );
}
