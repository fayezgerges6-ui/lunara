import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ShopProvider,
  SiteHeader,
  SiteFooter,
  ProductCard,
  categorySlug,
  fetchProducts,
} from "@/lib/shop";
import { searchProducts } from "@/lib/search-utils";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search.q === "string" ? search.q : "",
    cat: typeof search.cat === "string" ? search.cat : "",
    min: Number(search.min) || 0,
    max: Number(search.max) || 0,
    sort: typeof search.sort === "string" ? search.sort : "relevance",
  }),
  head: () => ({
    meta: [
      { title: "Search products — Lunara Cosmetics" },
      { name: "description", content: "Search the Lunara Cosmetics catalogue: oils, creams, scrubs, salts and hair care from the Zoganon collection." },
      { property: "og:title", content: "Search products — Lunara Cosmetics" },
      { property: "og:description", content: "Find your next ritual across the full Lunara catalogue." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const { q, cat, min, max, sort } = Route.useSearch();
  const navigate = useNavigate({ from: "/search" });
  const { lang } = useLang();
  const { data: products = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: fetchProducts });

  const term = q.trim();
  const base = term ? searchProducts(products, term) : products;
  const categories = Array.from(new Set(base.map((p) => p.category))).sort();

  const safeMin = Math.max(0, min);
  const safeMax = max > 0 ? max : Infinity;
  let results = base.filter(
    (p) => (!cat || p.category === cat) && p.price >= safeMin && p.price <= safeMax,
  );
  if (sort === "price-asc") results = [...results].sort((a, b) => a.price - b.price);
  else if (sort === "price-desc") results = [...results].sort((a, b) => b.price - a.price);
  else if (sort === "name") results = [...results].sort((a, b) => a.name.localeCompare(b.name));

  const setParam = (patch: Partial<{ q: string; cat: string; min: number; max: number; sort: string }>) =>
    navigate({ search: (prev: { q: string; cat: string; min: number; max: number; sort: string }) => ({ ...prev, ...patch }) });

  const ar = lang === "ar";

  return (
    <ShopProvider>
      <SiteHeader />
      <section className="zoganon" style={{ paddingTop: 40 }}>
        <div className="wrap">
          <div className="zog-head">
            <div>
              <p className="eyebrow">{ar ? "بحث" : "Search"}</p>
              <h2>
                {term
                  ? ar
                    ? `${results.length} نتيجة لـ "${q}"`
                    : `${results.length} results for "${q}"`
                  : ar
                    ? "دوّري على منتج"
                    : "Find a product"}
              </h2>
            </div>
          </div>

          <div className="filters">
            <label>
              <span>{ar ? "القسم" : "Category"}</span>
              <select value={cat} onChange={(e) => setParam({ cat: e.target.value })}>
                <option value="">{ar ? "كل الأقسام" : "All categories"}</option>
                {categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>
            <label>
              <span>{ar ? "أقل سعر" : "Min price"}</span>
              <input
                type="number"
                min={0}
                value={min || ""}
                placeholder="0"
                onChange={(e) => setParam({ min: Number(e.target.value) || 0 })}
              />
            </label>
            <label>
              <span>{ar ? "أعلى سعر" : "Max price"}</span>
              <input
                type="number"
                min={0}
                value={max || ""}
                placeholder="∞"
                onChange={(e) => setParam({ max: Number(e.target.value) || 0 })}
              />
            </label>
            <label>
              <span>{ar ? "ترتيب" : "Sort"}</span>
              <select value={sort} onChange={(e) => setParam({ sort: e.target.value })}>
                <option value="relevance">{ar ? "الأنسب" : "Relevance"}</option>
                <option value="price-asc">{ar ? "السعر: الأقل" : "Price: low to high"}</option>
                <option value="price-desc">{ar ? "السعر: الأعلى" : "Price: high to low"}</option>
                <option value="name">{ar ? "الاسم" : "Name"}</option>
              </select>
            </label>
            {(cat || min || max || sort !== "relevance") && (
              <button
                type="button"
                className="tab"
                onClick={() => setParam({ cat: "", min: 0, max: 0, sort: "relevance" })}
              >
                {ar ? "مسح الفلاتر" : "Clear filters"}
              </button>
            )}
          </div>

          <div className="grid">
            {results.map((p) => <ProductCard key={p.id} p={p} term={q} />)}
          </div>
          {results.length === 0 && !isLoading && (
            <div style={{ textAlign: "center", padding: "40px 0", opacity: 0.7 }}>
              <p>{ar ? "مفيش نتائج مطابقة." : "No matching products."}</p>
              <div className="tabs" style={{ justifyContent: "center", marginTop: 16 }}>
                {Array.from(new Set(products.map((p) => p.category))).sort().map((c) => (
                  <Link key={c} to="/category/$slug" params={{ slug: categorySlug(c) }} className="tab">{c}</Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
      <SiteFooter />
    </ShopProvider>
  );
}
