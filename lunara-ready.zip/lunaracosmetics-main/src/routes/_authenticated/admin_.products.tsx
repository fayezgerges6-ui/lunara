import { useMemo, useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { checkIsAdmin } from "@/lib/orders.functions";
import {
  listAllProducts,
  saveProduct,
  updateProductPrice,
  setProductActive,
  deleteProduct,
} from "@/lib/products.functions";
import { supabase } from "@/integrations/supabase/client";
import productFallback from "@/assets/product-placeholder.jpg";

export const Route = createFileRoute("/_authenticated/admin_/products")({
  head: () => ({
    meta: [
      { title: "Products — Lunara Admin" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminProductsPage,
});

type AdminProduct = {
  id: string;
  name: string;
  name_en: string | null;
  name_ar: string | null;
  description_en: string | null;
  description_ar: string | null;
  category: string;
  brand: string | null;
  brand_ar: string | null;
  price: number;
  image_url: string | null;
  active: boolean;
};

type Draft = {
  id?: string;
  name: string;
  name_en: string;
  name_ar: string;
  description_en: string;
  description_ar: string;
  category: string;
  brand: string;
  brand_ar: string;
  price: string;
  image_url: string;
  active: boolean;
};

const EMPTY_DRAFT: Draft = {
  name: "",
  name_en: "",
  name_ar: "",
  description_en: "",
  description_ar: "",
  category: "",
  brand: "",
  brand_ar: "",
  price: "",
  image_url: "",
  active: true,
};

function toDraft(p: AdminProduct): Draft {
  return {
    id: p.id,
    name: p.name ?? "",
    name_en: p.name_en ?? "",
    name_ar: p.name_ar ?? "",
    description_en: p.description_en ?? "",
    description_ar: p.description_ar ?? "",
    category: p.category ?? "",
    brand: p.brand ?? "",
    brand_ar: p.brand_ar ?? "",
    price: String(p.price ?? ""),
    image_url: p.image_url ?? "",
    active: p.active,
  };
}

// Shrinks big phone photos to a web-friendly JPEG (max 1200px) before upload.
async function prepareImage(file: File): Promise<Blob> {
  const bmp = await createImageBitmap(file);
  const max = 1200;
  const scale = Math.min(1, max / Math.max(bmp.width, bmp.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bmp.width * scale);
  canvas.height = Math.round(bmp.height * scale);
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not process image");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
  return new Promise((resolve, reject) =>
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("Could not process image"))), "image/jpeg", 0.86),
  );
}

async function uploadProductImage(file: File): Promise<string> {
  const blob = await prepareImage(file);
  const path = `${crypto.randomUUID()}.jpg`;
  const { error } = await supabase.storage
    .from("product-images")
    .upload(path, blob, { contentType: "image/jpeg", cacheControl: "31536000" });
  if (error) throw new Error(error.message);
  return supabase.storage.from("product-images").getPublicUrl(path).data.publicUrl;
}

function AdminProductsPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const checkFn = useServerFn(checkIsAdmin);
  const listFn = useServerFn(listAllProducts);
  const saveFn = useServerFn(saveProduct);
  const priceFn = useServerFn(updateProductPrice);
  const activeFn = useServerFn(setProductActive);
  const deleteFn = useServerFn(deleteProduct);

  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState<"all" | "active" | "hidden">("all");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [formError, setFormError] = useState("");
  const [uploading, setUploading] = useState(false);
  const [toDelete, setToDelete] = useState<AdminProduct | null>(null);
  const [notice, setNotice] = useState("");

  const adminCheck = useQuery({ queryKey: ["is-admin"], queryFn: () => checkFn() });
  const products = useQuery({
    queryKey: ["admin-products"],
    queryFn: () => listFn() as Promise<AdminProduct[]>,
    enabled: !!adminCheck.data?.isAdmin,
  });

  function refresh() {
    qc.invalidateQueries({ queryKey: ["admin-products"] });
    qc.invalidateQueries({ queryKey: ["products"] }); // storefront
  }

  function flash(msg: string) {
    setNotice(msg);
    setTimeout(() => setNotice(""), 2500);
  }

  const saveMut = useMutation({
    mutationFn: (d: Draft) =>
      saveFn({
        data: {
          id: d.id,
          name: d.name,
          name_en: d.name_en,
          name_ar: d.name_ar,
          description_en: d.description_en,
          description_ar: d.description_ar,
          category: d.category,
          brand: d.brand,
          brand_ar: d.brand_ar,
          price: Math.round(Number(d.price)),
          image_url: d.image_url,
          active: d.active,
        },
      }),
    onSuccess: (_r, d) => {
      refresh();
      setDraft(null);
      flash(d.id ? "Product updated ✓" : "Product added ✓");
    },
    onError: (e) => setFormError((e as Error).message),
  });

  const priceMut = useMutation({
    mutationFn: (v: { id: string; price: number }) => priceFn({ data: v }),
    onSuccess: () => {
      refresh();
      flash("Price saved ✓");
    },
    onError: (e) => flash((e as Error).message),
  });

  const activeMut = useMutation({
    mutationFn: (v: { id: string; active: boolean }) => activeFn({ data: v }),
    onSuccess: refresh,
    onError: (e) => flash((e as Error).message),
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      refresh();
      setToDelete(null);
      flash("Product deleted ✓");
    },
    onError: (e) => flash((e as Error).message),
  });

  const all = (products.data ?? []) as AdminProduct[];

  const categories = useMemo(() => Array.from(new Set(all.map((p) => p.category))).sort(), [all]);
  const brands = useMemo(
    () => Array.from(new Set(all.map((p) => p.brand).filter(Boolean) as string[])).sort(),
    [all],
  );
  const brandsAr = useMemo(
    () => Array.from(new Set(all.map((p) => p.brand_ar).filter(Boolean) as string[])).sort(),
    [all],
  );

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return all.filter((p) => {
      if (categoryFilter && p.category !== categoryFilter) return false;
      if (statusFilter === "active" && !p.active) return false;
      if (statusFilter === "hidden" && p.active) return false;
      if (!q) return true;
      return [p.name, p.name_en, p.name_ar, p.brand, p.brand_ar, p.category, p.id]
        .filter(Boolean)
        .some((s) => (s as string).toLowerCase().includes(q));
    });
  }, [all, search, categoryFilter, statusFilter]);

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  async function onPickImage(file: File | undefined) {
    if (!file || !draft) return;
    setFormError("");
    setUploading(true);
    try {
      const url = await uploadProductImage(file);
      setDraft((d) => (d ? { ...d, image_url: url } : d));
    } catch (e) {
      setFormError(`Image upload failed: ${(e as Error).message}`);
    } finally {
      setUploading(false);
    }
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!draft) return;
    setFormError("");
    const price = Number(draft.price);
    if (!draft.name.trim()) return setFormError("Product name is required.");
    if (!draft.category.trim()) return setFormError("Category is required.");
    if (!Number.isFinite(price) || price < 0) return setFormError("Enter a valid price.");
    saveMut.mutate(draft);
  }

  function setField<K extends keyof Draft>(key: K, value: Draft[K]) {
    setDraft((d) => (d ? { ...d, [key]: value } : d));
  }

  if (adminCheck.isLoading) return <div className="admin-page">Loading…</div>;
  if (!adminCheck.data?.isAdmin) {
    return (
      <div className="admin-page">
        <h1>Not authorized</h1>
        <p className="sub">This account is signed in but does not have admin access.</p>
        <button className="btn" onClick={signOut}>Sign out</button>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
        <div>
          <h1>Products</h1>
          <p className="sub">
            {all.length} products · {all.filter((p) => !p.active).length} hidden
          </p>
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
          <Link to="/admin" className="btn ghost">Orders</Link>
          <Link to="/" className="btn ghost">View store</Link>
          <button
            className="btn"
            onClick={() => {
              setFormError("");
              setDraft({ ...EMPTY_DRAFT });
            }}
          >
            + Add product
          </button>
        </div>
      </div>

      <div className="pa-toolbar">
        <input
          className="pa-input"
          placeholder="Search by name, brand, category…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <select className="pa-input" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
          <option value="">All categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
        <select
          className="pa-input"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value as "all" | "active" | "hidden")}
        >
          <option value="all">All</option>
          <option value="active">Visible in store</option>
          <option value="hidden">Hidden</option>
        </select>
      </div>

      {notice && <div className="pa-toast">{notice}</div>}
      {products.isLoading && <p>Loading products…</p>}
      {products.error && <p className="error-msg">{(products.error as Error).message}</p>}

      <div className="pa-list">
        {filtered.map((p) => (
          <div className={`pa-row${p.active ? "" : " pa-hidden"}`} key={p.id}>
            <img
              className="pa-thumb"
              src={p.image_url && p.image_url.trim() ? p.image_url : productFallback}
              alt=""
              loading="lazy"
            />
            <div className="pa-main">
              <div className="pa-name">{p.name_en || p.name}</div>
              {p.name_ar && <div className="pa-name-ar" dir="rtl">{p.name_ar}</div>}
              <div className="pa-meta">
                {p.category}
                {p.brand ? ` · ${p.brand}` : ""}
              </div>
            </div>
            <div className="pa-price">
              <span>E£</span>
              <input
                key={`${p.id}-${p.price}`}
                type="number"
                min={0}
                step={1}
                defaultValue={p.price}
                aria-label={`Price of ${p.name}`}
                onBlur={(e) => {
                  const v = Math.round(Number(e.target.value));
                  if (Number.isFinite(v) && v >= 0 && v !== p.price) priceMut.mutate({ id: p.id, price: v });
                  else e.target.value = String(p.price);
                }}
                onKeyDown={(e) => {
                  if (e.key === "Enter") (e.target as HTMLInputElement).blur();
                }}
              />
            </div>
            <label className="pa-switch" title={p.active ? "Visible in store" : "Hidden from store"}>
              <input
                type="checkbox"
                checked={p.active}
                onChange={(e) => activeMut.mutate({ id: p.id, active: e.target.checked })}
              />
              <span>{p.active ? "Visible" : "Hidden"}</span>
            </label>
            <div className="pa-actions">
              <button
                className="btn ghost pa-small"
                onClick={() => {
                  setFormError("");
                  setDraft(toDraft(p));
                }}
              >
                Edit
              </button>
              <button className="btn ghost pa-small pa-danger" onClick={() => setToDelete(p)}>
                Delete
              </button>
            </div>
          </div>
        ))}
        {!products.isLoading && filtered.length === 0 && <p className="sub">No products match.</p>}
      </div>

      {/* Add / edit panel */}
      {draft && (
        <div className="pa-overlay" onClick={() => !saveMut.isPending && setDraft(null)}>
          <form className="pa-modal" onClick={(e) => e.stopPropagation()} onSubmit={submit}>
            <h2>{draft.id ? "Edit product" : "Add product"}</h2>

            <div className="pa-image-box">
              <img
                src={draft.image_url.trim() ? draft.image_url : productFallback}
                alt=""
                className="pa-image-preview"
              />
              <div className="pa-image-controls">
                <label className="btn ghost pa-small" style={{ cursor: "pointer" }}>
                  {uploading ? "Uploading…" : draft.image_url ? "Change image" : "Upload image"}
                  <input
                    type="file"
                    accept="image/*"
                    hidden
                    disabled={uploading}
                    onChange={(e) => {
                      onPickImage(e.target.files?.[0]);
                      e.target.value = "";
                    }}
                  />
                </label>
                {draft.image_url && (
                  <button type="button" className="btn ghost pa-small" onClick={() => setField("image_url", "")}>
                    Remove
                  </button>
                )}
                <input
                  className="pa-input"
                  placeholder="…or paste an image URL"
                  value={draft.image_url}
                  onChange={(e) => setField("image_url", e.target.value)}
                />
              </div>
            </div>

            <div className="pa-grid">
              <label>
                Name (internal / fallback) *
                <input className="pa-input" value={draft.name} onChange={(e) => setField("name", e.target.value)} />
              </label>
              <label>
                Price (E£) *
                <input
                  className="pa-input"
                  type="number"
                  min={0}
                  step={1}
                  value={draft.price}
                  onChange={(e) => setField("price", e.target.value)}
                />
              </label>
              <label>
                Name — English
                <input className="pa-input" value={draft.name_en} onChange={(e) => setField("name_en", e.target.value)} />
              </label>
              <label>
                Name — Arabic
                <input className="pa-input" dir="rtl" value={draft.name_ar} onChange={(e) => setField("name_ar", e.target.value)} />
              </label>
              <label>
                Category *
                <input
                  className="pa-input"
                  list="pa-categories"
                  value={draft.category}
                  onChange={(e) => setField("category", e.target.value)}
                />
              </label>
              <label>
                Brand
                <input
                  className="pa-input"
                  list="pa-brands"
                  value={draft.brand}
                  onChange={(e) => setField("brand", e.target.value)}
                />
              </label>
              <label>
                Brand — Arabic
                <input
                  className="pa-input"
                  dir="rtl"
                  list="pa-brands-ar"
                  value={draft.brand_ar}
                  onChange={(e) => setField("brand_ar", e.target.value)}
                />
              </label>
              <label className="pa-switch" style={{ alignSelf: "end", paddingBottom: 10 }}>
                <input type="checkbox" checked={draft.active} onChange={(e) => setField("active", e.target.checked)} />
                <span>Visible in store</span>
              </label>
              <label className="pa-wide">
                Description — English
                <textarea
                  className="pa-input"
                  rows={3}
                  value={draft.description_en}
                  onChange={(e) => setField("description_en", e.target.value)}
                />
              </label>
              <label className="pa-wide">
                Description — Arabic
                <textarea
                  className="pa-input"
                  dir="rtl"
                  rows={3}
                  value={draft.description_ar}
                  onChange={(e) => setField("description_ar", e.target.value)}
                />
              </label>
            </div>

            <datalist id="pa-categories">
              {categories.map((c) => <option key={c} value={c} />)}
            </datalist>
            <datalist id="pa-brands">
              {brands.map((b) => <option key={b} value={b} />)}
            </datalist>
            <datalist id="pa-brands-ar">
              {brandsAr.map((b) => <option key={b} value={b} />)}
            </datalist>

            {formError && <p className="error-msg">{formError}</p>}

            <div className="pa-modal-actions">
              <button type="button" className="btn ghost" disabled={saveMut.isPending} onClick={() => setDraft(null)}>
                Cancel
              </button>
              <button type="submit" className="btn" disabled={saveMut.isPending || uploading}>
                {saveMut.isPending ? "Saving…" : draft.id ? "Save changes" : "Add product"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete confirmation */}
      {toDelete && (
        <div className="pa-overlay" onClick={() => !deleteMut.isPending && setToDelete(null)}>
          <div className="pa-modal pa-confirm" onClick={(e) => e.stopPropagation()}>
            <h2>Delete this product?</h2>
            <p style={{ margin: "10px 0 6px" }}><strong>{toDelete.name_en || toDelete.name}</strong></p>
            <p className="sub" style={{ marginBottom: 18 }}>
              It will be removed from the store permanently. Past orders keep their saved name and price. If you only
              want to take it off the shop for now, use “Hidden” instead.
            </p>
            <div className="pa-modal-actions">
              <button className="btn ghost" disabled={deleteMut.isPending} onClick={() => setToDelete(null)}>
                Cancel
              </button>
              <button
                className="btn pa-danger-solid"
                disabled={deleteMut.isPending}
                onClick={() => deleteMut.mutate(toDelete.id)}
              >
                {deleteMut.isPending ? "Deleting…" : "Delete"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
