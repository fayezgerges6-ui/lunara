import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { listOrders, updateOrderStatus, checkIsAdmin } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";

const STATUSES = ["pending", "confirmed", "paid", "shipping", "delivered", "cancelled"] as const;
type Status = (typeof STATUSES)[number];

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({
    meta: [
      { title: "Orders — Lunara Admin" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: AdminPage,
});

function AdminPage() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const listFn = useServerFn(listOrders);
  const updateFn = useServerFn(updateOrderStatus);
  const checkFn = useServerFn(checkIsAdmin);

  const adminCheck = useQuery({ queryKey: ["is-admin"], queryFn: () => checkFn() });
  const orders = useQuery({
    queryKey: ["orders"],
    queryFn: () => listFn(),
    enabled: !!adminCheck.data?.isAdmin,
  });

  const mutation = useMutation({
    mutationFn: (v: { id: string; status?: Status; estimated_delivery?: string | null; admin_note?: string | null }) =>
      updateFn({ data: v }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["orders"] }),
  });

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  }

  if (adminCheck.isLoading) return <div className="admin-page">Loading…</div>;
  if (!adminCheck.data?.isAdmin) {
    return (
      <div className="admin-page">
        <h1>Not authorized</h1>
        <p className="sub">This account is signed in but does not have admin access.</p>
        <button className="btn" onClick={signOut}>Sign out</button>
      </div>
    );
  }

  return (
    <div className="admin-page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
        <div>
          <h1>Orders</h1>
          <p className="sub">{orders.data?.length ?? 0} orders</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Link to="/admin/products" className="btn">Products</Link>
          <Link to="/" className="btn ghost">View store</Link>
          <button className="btn" onClick={signOut}>Sign out</button>
        </div>
      </div>

      {orders.isLoading && <p>Loading orders…</p>}
      {orders.error && <p className="error-msg">{(orders.error as Error).message}</p>}

      <div className="orders-list">
        {(orders.data ?? []).map((o) => (
          <div className="order-card" key={o.id}>
            <div className="order-head">
              <div>
                <div className="order-num">#{o.order_number}</div>
                <div className="order-meta">
                  {new Date(o.created_at).toLocaleString("en-GB")} · {o.customer_name} · {o.customer_phone}
                </div>
              </div>
              <span className={`status-badge st-${o.status}`}>{o.status}</span>
            </div>
            <div className="order-body">
              <div>
                <ul className="order-items">
                  {((o.order_items ?? []) as { id: string; product_name: string; quantity: number; price: number }[]).map((it) => (
                    <li key={it.id}>• {it.product_name} × {it.quantity} = E£{it.price * it.quantity}</li>
                  ))}
                </ul>
              </div>
              <div style={{ fontSize: 13, opacity: 0.85 }}>
                <div><strong>Address:</strong> {o.customer_address}</div>
                {o.city && <div><strong>City:</strong> {o.city}</div>}
                {o.notes && <div><strong>Notes:</strong> {o.notes}</div>}
                <div style={{ marginTop: 8, fontSize: 16, fontFamily: "Instrument Serif, serif" }}>
                  Total: <strong>E£{o.total}</strong>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 200 }}>
                <label style={{ fontSize: 12, opacity: 0.7 }}>Status</label>
                <select
                  className="status-select"
                  value={o.status}
                  onChange={(e) => mutation.mutate({ id: o.id, status: e.target.value as Status })}
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>

                <label style={{ fontSize: 12, opacity: 0.7, marginTop: 4 }}>Estimated delivery</label>
                <input
                  type="date"
                  className="status-select"
                  defaultValue={(o as { estimated_delivery?: string | null }).estimated_delivery ?? ""}
                  onBlur={(e) => {
                    const v = e.target.value || null;
                    if (v !== ((o as { estimated_delivery?: string | null }).estimated_delivery ?? null)) {
                      mutation.mutate({ id: o.id, estimated_delivery: v });
                    }
                  }}
                />

                <label style={{ fontSize: 12, opacity: 0.7, marginTop: 4 }}>Admin note (shown to customer)</label>
                <textarea
                  className="status-select"
                  rows={2}
                  defaultValue={(o as { admin_note?: string | null }).admin_note ?? ""}
                  onBlur={(e) => {
                    const v = e.target.value.trim() || null;
                    if (v !== ((o as { admin_note?: string | null }).admin_note ?? null)) {
                      mutation.mutate({ id: o.id, admin_note: v });
                    }
                  }}
                />
              </div>
            </div>
          </div>
        ))}
        {orders.data?.length === 0 && !orders.isLoading && <p className="sub">No orders yet.</p>}
      </div>
    </div>
  );
}
