import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { listMyOrders } from "@/lib/orders.functions";
import { supabase } from "@/integrations/supabase/client";
import { useLang } from "@/lib/i18n";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({
    meta: [
      { title: "My orders — Lunara" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: OrdersPage,
});

function OrdersPage() {
  const navigate = useNavigate();
  const { t, lang } = useLang();
  const listFn = useServerFn(listMyOrders);
  const orders = useQuery({ queryKey: ["my-orders"], queryFn: () => listFn() });

  async function signOut() {
    await supabase.auth.signOut();
    navigate({ to: "/" });
  }

  return (
    <div className="admin-page">
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 20 }}>
        <div>
          <h1>{t("my_orders")}</h1>
          <p className="sub">{orders.data?.length ?? 0} {lang === "ar" ? "طلب" : "orders"}</p>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <Link to="/" className="btn ghost">{t("back_store")}</Link>
          <button className="btn" onClick={signOut}>{t("signout")}</button>
        </div>
      </div>

      {orders.isLoading && <p>…</p>}
      {orders.error && <p className="error-msg">{(orders.error as Error).message}</p>}

      <div className="orders-list">
        {(orders.data ?? []).map((o) => (
          <div className="order-card" key={o.id}>
            <div className="order-head">
              <div>
                <div className="order-num">#{o.order_number}</div>
                <div className="order-meta">
                  {t("on_date")} {new Date(o.created_at).toLocaleString(lang === "ar" ? "ar-EG" : "en-GB")}
                </div>
              </div>
              <span className={`status-badge st-${o.status}`}>{o.status}</span>
            </div>
            <div className="order-body" style={{ gridTemplateColumns: "1fr" }}>
              <ul className="order-items">
                {((o.order_items ?? []) as { id: string; product_name: string; quantity: number; price: number }[]).map((it) => (
                  <li key={it.id}>• {it.product_name} × {it.quantity} = E£{it.price * it.quantity}</li>
                ))}
              </ul>
              {(o as { estimated_delivery?: string | null }).estimated_delivery && (
                <div style={{ marginTop: 6, fontSize: 14 }}>
                  🚚 {lang === "ar" ? "الوصول المتوقع" : "Estimated delivery"}:{" "}
                  <strong>
                    {new Date((o as { estimated_delivery: string }).estimated_delivery).toLocaleDateString(lang === "ar" ? "ar-EG" : "en-GB")}
                  </strong>
                </div>
              )}
              {(o as { admin_note?: string | null }).admin_note && (
                <div style={{ marginTop: 6, fontSize: 14, opacity: 0.85 }}>
                  📝 {(o as { admin_note: string }).admin_note}
                </div>
              )}
              <div style={{ marginTop: 8, fontSize: 16, fontFamily: "Instrument Serif, serif" }}>
                {t("total")}: <strong>E£{o.total}</strong>
              </div>
            </div>
          </div>
        ))}
        {orders.data?.length === 0 && !orders.isLoading && <p className="sub">{t("no_orders")}</p>}
      </div>
    </div>
  );
}
