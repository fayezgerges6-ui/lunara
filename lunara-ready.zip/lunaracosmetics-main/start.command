#!/bin/bash
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Install Node.js from https://nodejs.org first"; exit 1; }
[ -d node_modules ] || npm install --no-package-lock
(sleep 5; open http://localhost:8080 2>/dev/null || xdg-open http://localhost:8080) &
npm run dev
