
ALTER TABLE public.orders ADD COLUMN user_id uuid;
CREATE INDEX orders_user_id_idx ON public.orders(user_id);

CREATE POLICY "users read own orders" ON public.orders
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "users read own order items" ON public.order_items
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_items.order_id AND o.user_id = auth.uid()));
