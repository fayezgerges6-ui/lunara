ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS name_ar text,
  ADD COLUMN IF NOT EXISTS name_en text,
  ADD COLUMN IF NOT EXISTS description_en text,
  ADD COLUMN IF NOT EXISTS description_ar text;

CREATE TABLE public.search_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  query text,
  product_id text,
  category text,
  min_price integer,
  max_price integer,
  sort text,
  results_count integer,
  lang text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT INSERT ON public.search_events TO anon, authenticated;
GRANT SELECT ON public.search_events TO authenticated;
GRANT ALL ON public.search_events TO service_role;

ALTER TABLE public.search_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone can log search events"
  ON public.search_events FOR INSERT TO anon, authenticated
  WITH CHECK (true);

CREATE POLICY "admins read search events"
  ON public.search_events FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));

CREATE INDEX idx_search_events_created_at ON public.search_events (created_at DESC);
CREATE INDEX idx_search_events_type ON public.search_events (event_type);