-- Enum for order status
CREATE TYPE public.order_status AS ENUM ('pending','confirmed','paid','shipping','delivered','cancelled');

-- Roles
CREATE TYPE public.app_role AS ENUM ('admin','user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "users read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;

CREATE OR REPLACE FUNCTION public.grant_first_user_admin()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM public.user_roles WHERE role = 'admin') THEN
    INSERT INTO public.user_roles(user_id, role) VALUES (NEW.id, 'admin');
  END IF;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created_grant_admin
AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.grant_first_user_admin();

-- Products
CREATE TABLE public.products (
  id text PRIMARY KEY,
  name text NOT NULL,
  category text NOT NULL,
  price integer NOT NULL,
  image_url text,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.products TO anon, authenticated;
GRANT ALL ON public.products TO service_role;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
CREATE POLICY "public read products" ON public.products FOR SELECT TO anon, authenticated USING (active = true);
CREATE POLICY "admins manage products" ON public.products FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

-- Orders
CREATE TABLE public.orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number serial UNIQUE,
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  customer_address text NOT NULL,
  city text,
  notes text,
  total integer NOT NULL,
  status public.order_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, UPDATE ON public.orders TO authenticated;
GRANT ALL ON public.orders TO service_role;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins read orders" ON public.orders FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));
CREATE POLICY "admins update orders" ON public.orders FOR UPDATE TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id text NOT NULL,
  product_name text NOT NULL,
  price integer NOT NULL,
  quantity integer NOT NULL
);
GRANT SELECT ON public.order_items TO authenticated;
GRANT ALL ON public.order_items TO service_role;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins read items" ON public.order_items FOR SELECT TO authenticated USING (public.has_role(auth.uid(),'admin'));

CREATE INDEX orders_created_at_idx ON public.orders(created_at DESC);
CREATE INDEX order_items_order_id_idx ON public.order_items(order_id);

-- Seed products
INSERT INTO public.products(id, name, category, price) VALUES ('z0','ANTI CELLULITE MASSAGE OIL 125 ML','Massage Oils',250),('z1','ANTI STRESS MASSAGE OIL 125 ML','Massage Oils',250),('z2','ANTI WRINKLES CREAM 165 ML','Face & Body Creams',350),('z3','ARGAN CREAM 165 ML','Face & Body Creams',250),('z4','AROMA MASSAGES OIL WITH BLUE CHAMOMILE 125 ML','Massage Oils',250),('z5','AROMA MASSAGES OIL WITH EUCALYPTOS 125 ML','Massage Oils',250),('z6','AROMA MASSAGES OIL WITH GERANIUM 125 ML','Massage Oils',250),('z7','AROMA MASSAGES OIL WITH LAVENDER 125 ML','Massage Oils',250),('z8','AROMA MASSAGES OIL WITH LEMONGRASS 125 ML','Massage Oils',250),('z9','AROMA MASSAGES OIL WITH ORANGE 125 ML','Massage Oils',250),('z10','AROMA MASSAGES OIL WITH PEPPERMINT 125 ML','Massage Oils',250),('z11','AYUREVEDIC MASSAGE OIL 125 ML','Massage Oils',250),('z12','BEARD SERUM 30 ML','Serums & Extras',200),('z13','BLACK SEED OIL 125 ML','Pure & Carrier Oils',200),('z14','BRONZING OIL 60 ML','Pure & Carrier Oils',175),('z15','CAMEL MILK CREAM 165 GM','Face & Body Creams',400),('z16','CASTOR OIL 125 ML','Pure & Carrier Oils',100),('z17','COCONUT OIL 125 ML','Pure & Carrier Oils',125),('z18','COFFEE BEANS SCRUB WITH CHAMOMILE 330 ML','Scrubs & Bath Salts',200),('z19','COFFEE BEANS SCRUB WITH EUCALYPTUS 330 ML','Scrubs & Bath Salts',200),('z20','COFFEE BEANS SCRUB WITH GERANIUM 330 ML','Scrubs & Bath Salts',200),('z21','COFFEE BEANS SCRUB WITH LEMONGRASS 330 ML','Scrubs & Bath Salts',200),('z22','COFFEE BEANS SCRUB WITH ORANGE 330 ML','Scrubs & Bath Salts',200),('z23','COFFEE BEANS SCRUB WITH PEPPERMINT 330 ML','Scrubs & Bath Salts',200),('z24','Colagen Booster Cream 165 Gm','Face & Body Creams',420),('z25','COLLAGEN BOOSTER 165 ML','Face & Body Creams',250),('z26','CYPERUS OIL 125 ML','Pure & Carrier Oils',200),('z27','CYPERUS OIL 60 ML','Pure & Carrier Oils',150),('z28','EGYPTIAN MASSAGE OIL 125 ML','Massage Oils',250),('z29','EPSOM SALT WITH CHAMOMILE OIL 370 ML','Scrubs & Bath Salts',150),('z30','EPSOM SALT WITH CITRUS OIL 370 ML','Scrubs & Bath Salts',150),('z31','EPSOM SALT WITH EUCALYPTUS OIL 370 ML','Scrubs & Bath Salts',150),('z32','EPSOM SALT WITH GERANIUM OIL 370 ML','Scrubs & Bath Salts',150),('z33','EPSOM SALT WITH LEMONGRASS OIL 370 ML','Scrubs & Bath Salts',150),('z34','EPSOM SALT WITH ORANGE OIL 370 ML','Scrubs & Bath Salts',150),('z35','EPSOM SALT WITH PEPPERMINT OIL 370 ML','Scrubs & Bath Salts',150),('z36','FACE&NEEK MASSAGE OIL 125 ML','Massage Oils',250),('z37','FOOT CREAM 165 ML','Face & Body Creams',275),('z38','FRAGRANCE OIL AGAR WOOD 30 ML','Fragrance Oils',125),('z39','FRAGRANCE OIL APPLE 30 ML','Fragrance Oils',125),('z40','FRAGRANCE OIL CINNAMON 30 ML','Fragrance Oils',125),('z41','FRAGRANCE OIL COCONUT 30 ML','Fragrance Oils',125),('z42','FRAGRANCE OIL EGYPTIAN JASMINE 30 ML','Fragrance Oils',125),('z43','FRAGRANCE OIL GARDENIA 30 ML','Fragrance Oils',125),('z44','FRAGRANCE OIL JASMINE 30 ML','Fragrance Oils',125),('z45','FRAGRANCE OIL LAVENDER 30 ML','Fragrance Oils',125),('z46','FRAGRANCE OIL LEMON 30 ML','Fragrance Oils',125),('z47','FRAGRANCE OIL MANGO 30 ML','Fragrance Oils',125),('z48','FRAGRANCE OIL MIXED FRUITS 30 ML','Fragrance Oils',125),('z49','FRAGRANCE OIL ORANGE 30 ML','Fragrance Oils',125),('z50','FRAGRANCE OIL PATCHOULI 30 ML','Fragrance Oils',125),('z51','FRAGRANCE OIL PEACH 30 ML','Fragrance Oils',125),('z52','FRAGRANCE OIL PINEAPPLE 30 ML','Fragrance Oils',125),('z53','FRAGRANCE OIL ROSE 30 ML','Fragrance Oils',125),('z54','FRAGRANCE OIL SANDAL WOOD 30 ML','Fragrance Oils',125),('z55','FRAGRANCE OIL STRAWBERRY 30 ML','Fragrance Oils',125),('z56','FRAGRANCE OIL VANILLA 30 ML','Fragrance Oils',125),('z57','FRAGRANCE OIL VIOLET 30 ML','Fragrance Oils',125),('z58','FRAGRANCE OIL WHITE MUSK 30 ML','Fragrance Oils',125),('z59','GERANIUM WATER 125 ML','Floral Waters & Toners',75),('z60','GOAT MILK CREAM 165 GM','Face & Body Creams',430),('z61','GOOSBERRY OIL 125 ML','Pure & Carrier Oils',200),('z62','HAIR CONDITIONER WITH ARGAN 200 ML','Hair Care',145),('z63','HAIR CONDITIONER WITH JOJOBA 200 ML','Hair Care',145),('z64','HAIR CREAM FOR ALL HAIR TYPES 165 ML','Hair Care',175),('z65','HAIR CREAM FOR NORMAL TO DRY HAIR 165 ML','Hair Care',195),('z66','HAIR FOOD OIL 125 ML','Hair Care',200),('z67','JOJOBA OIL 125 ML','Pure & Carrier Oils',200),('z68','LAVENDER WATER 125 ML','Floral Waters & Toners',75) ON CONFLICT (id) DO NOTHING;